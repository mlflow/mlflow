library(mlflow)

mlflow_log_param("parameter", 5)
mlflow_log_metric("metric", 0)
