# Databricks AI Gateway Private Preview Documentation

This directory contains private preview documentation for the AI Gateway.

To access the documentation:

1. Open a terminal and enter the directory containing this README file
2. Run ``open html/gateway/index.html``

For any questions, please reach out to your Databricks representative.
